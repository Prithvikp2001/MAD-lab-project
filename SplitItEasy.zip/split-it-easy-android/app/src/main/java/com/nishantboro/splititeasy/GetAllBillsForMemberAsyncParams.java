package com.nishantboro.splititeasy;

class GetAllBillsForMemberAsyncParams {

    String gName;
    int mid;

    GetAllBillsForMemberAsyncParams(String gName, int mid) {
        this.gName = gName;
        this.mid = mid;
    }
}
